package io.quarkiverse.langchain4j.workshop.triage;

public enum Evaluation {

    POSITIVE,
    NEGATIVE
}
