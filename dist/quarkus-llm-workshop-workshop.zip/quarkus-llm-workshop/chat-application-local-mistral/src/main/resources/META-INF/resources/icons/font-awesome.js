// import './font-awesome-brands.js';
// import './font-awesome-regular.js';
import './font-awesome-solid.js';

// export * from './font-awesome-brands.js';
// export * from './font-awesome-regular.js';
export * from './font-awesome-solid.js';
