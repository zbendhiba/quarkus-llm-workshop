# Quarkus LLM Workshop

This is a revised version of https://github.com/cescoffier/quarkus-llm-worksho tailored for Red Hat Summit 2024.

Please revise the license https://github.com/cescoffier/quarkus-llm-workshop/blob/main/LICENSE before usage.



