#!/bin/bash

cd docs
pip install pipenv
pipenv install
